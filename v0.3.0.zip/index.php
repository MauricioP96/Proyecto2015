<?php
header('Location: controlador/frontend_controller.php');
?>

